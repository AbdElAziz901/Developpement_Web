
"""Prédit le type de navire et renvoie le résultat au format JSON."""

import argparse
import json
import random

def verifier_arguments():
    """Vérifie les arguments passés en ligne de commande et les retourne."""
    parser = argparse.ArgumentParser(description="Prédire le type de navire à partir de ses caractéristiques.")
    parser.add_argument('--sog', type=float, required=True, help='Vitesse sur le fond (Speed Over Ground)')
    parser.add_argument('--cog', type=float, required=True, help='Cap sur le fond (Course Over Ground)')
    parser.add_argument('--latitude', type=float, required=True, help='Latitude')
    parser.add_argument('--longitude', type=float, required=True, help='Longitude')
    parser.add_argument('--heading', type=float, required=True, help='Cap vrai (True heading)')
    parser.add_argument('--length', type=float, required=True, help='Longueur du navire')
    parser.add_argument('--width', type=float, required=True, help='Largeur du navire')
    parser.add_argument('--draft', type=float, required=True, help='Tirant')
    parser.add_argument('--status', type=int, required=True, help='Statut de navigation')
    parser.add_argument('-t', '--time', type=str, required=True, help='Date et heure UTC complète')
    return parser.parse_args()

# Programme principal.
args = verifier_arguments()

# Simulation de prédiction aléatoire
pred = random.randint(1, 5)
resultat = "Resultat"

if pred == 1:
    resultat = "Passenger"
elif pred == 2:
    resultat = "Tanker"
elif pred == 3:
    resultat = "Cargo"
elif pred == 4:
    resultat = "Fishing"
else:
    resultat = "Other"

# Affichage du résultat JSON correctement formé
print(json.dumps({"prediction": resultat}), end='', flush=True)
