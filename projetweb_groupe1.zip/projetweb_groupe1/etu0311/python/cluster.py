import argparse
import random
import json

def checkArguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('--sog', type=float, required=True)
    parser.add_argument('--cog', type=float, required=True)
    parser.add_argument('--latitude', type=float, required=True)
    parser.add_argument('--longitude', type=float, required=True)
    parser.add_argument('--heading', type=float, required=True)
    parser.add_argument('--length', type=float, required=True)
    parser.add_argument('--width', type=float, required=True)
    parser.add_argument('--draft', type=float, required=True)
    parser.add_argument('--status', type=int, required=True)
    parser.add_argument('-t', '--time', type=str, required=True)
    return parser.parse_args()

args = checkArguments()

# Construction du dictionnaire de sortie
result = {
    "cluster": random.randint(1, 5)
}

# Envoi du JSON sans saut de ligne en trop
print(json.dumps(result), end='', flush=True)
