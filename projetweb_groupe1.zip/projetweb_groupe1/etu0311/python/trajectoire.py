import argparse
import json
import random
import math

def checkArguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lat', type=str, required=True)
    parser.add_argument('--lon', type=str, required=True)
    parser.add_argument('--sog', type=str, required=True)
    parser.add_argument('--heading', type=str, required=True)
    return parser.parse_args()

args = checkArguments()

try:
    # Décodage des valeurs
    latitude = float(args.lat)
    longitude = float(args.lon)
    SOG = float(args.sog)  # en nœuds
    Heading = float(args.heading)  # en degrés

    # Paramètres
    R = 6371  # Rayon de la Terre en km
    time_min = 1  # Durée de prédiction en minutes

    # Conversion SOG en km/min
    speed_km_min = SOG * 1.852 / 60

    # Distance angulaire (en radians)
    delta = speed_km_min / R

    # Conversion en radians
    latitude_rad = math.radians(latitude)
    longitude_rad = math.radians(longitude)
    heading_rad = math.radians(Heading)

    # Formules de navigation
    latitude_rad2 = math.asin(math.sin(latitude_rad) * math.cos(delta) +
                     math.cos(latitude_rad) * math.sin(delta) * math.cos(heading_rad))

    longitude_rad2 = longitude_rad + math.atan2(math.sin(heading_rad) * math.sin(delta) * math.cos(latitude_rad),
                             math.cos(delta) - math.sin(latitude_rad) * math.sin(latitude_rad2))

    # Conversion en degrés
    latitude_predite = math.degrees(latitude_rad2)
    longitude_predite = math.degrees(longitude_rad2)

    # Affichage JSON
    result = {
        "latitude_origine": latitude,
        "longitude_origine": longitude,
        "latitude_predite": latitude_predite,
        "longitude_predite": longitude_predite
    }
    print(json.dumps(result))

except Exception as e:
    print(json.dumps({
        "error": "Exception in Python script",
        "message": str(e)
    }))
    exit(1)