<?php
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);

error_log(print_r($input, true));

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Entrée JSON invalide']);
    exit;
}

$sog = escapeshellarg($input['SOG']);
$cog = escapeshellarg($input['COG'] ?? 0);
$latitude = escapeshellarg($input['latitude'] ?? 0);
$longitude = escapeshellarg($input['longitude'] ?? 0);
$heading = escapeshellarg($input['heading'] ?? 0);
$length = escapeshellarg($input['longueur'] ?? 0);
$width = escapeshellarg($input['largeur'] ?? 0);
$draft = escapeshellarg($input['tirant'] ?? 0);
$status = escapeshellarg($input['state_id'] ?? 0);
$time = escapeshellarg($input['created_at'] ?? '');

$command = "python3 ../python/cluster.py"
    . " --sog $sog"
    . " --cog $cog"
    . " --latitude $latitude"
    . " --longitude $longitude"
    . " --heading $heading"
    . " --length $length"
    . " --width $width"
    . " --draft $draft"
    . " --status $status"
    . " --time $time";

// Exécution  du script Python et récupération de la sortie

$output = 0;
$return_var = 0;
exec($command, $output, $return_var);

if ($return_var !== 0) {
    echo json_encode(['error' => 'Erreur lors de l\'exécution du script Python', 'details' => $output]);
    exit;
}

// Retourner la sortie JSON du script Python
header('Content-Type: application/json; charset=utf-8');
echo implode("", $output);


