<?php

$host = "localhost";
$username = "etu0311";         
$password = "lnnkbaql"; 
$dbname = "etu0311";

// Connexion à la base

$conn = new mysqli($host, $username, $password, $dbname);
$conn->set_charset("utf8");

// Vérification

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Requête pour obtenir les tables

$sql = "SELECT 
            boat.*,
            state.name AS state_name,
            data_point.* 
        FROM 
            boat
        INNER JOIN 
            state ON boat.id_state = state.id  
        INNER JOIN 
            data_point ON boat.MMSI = data_point.MMSI;
    ";

$result = $conn->query($sql);

$json = json_encode($result->fetch_all(MYSQLI_ASSOC)); 

// Modification du header de la réponse pour dire que l'on envoie du json

header('Content-Type: application/json; charset=utf-8');

// Envoie du json

echo $json;