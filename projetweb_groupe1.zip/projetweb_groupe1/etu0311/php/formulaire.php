<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once("basededonnee.php");

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["success" => false, "error" => "Méthode non autorisée, utilisez POST"]);
    exit;
}

$db = dbConnect();
if (!$db) {
    http_response_code(500);
    echo json_encode(["success" => false, "error" => "Échec de connexion à la base de données"]);
    exit;
}

// Liste des champs attendus
$expectedFields = ['mmsi','nom','jour','mois','annee','heure','minutes','secondes','longitude','latitude','sog','cog','heading','status','longueur','largeur','tirant'];

foreach ($expectedFields as $field) {
    if (!isset($_POST[$field]) || $_POST[$field] === '') {
        http_response_code(400);
        echo json_encode(["success" => false, "error" => "Le champ '$field' est manquant ou vide"]);
        exit;
    }
}

try {
    // Conversion des types
    $mmsi = intval($_POST['mmsi']);
    $nom = $_POST['nom'];
    $jour = intval($_POST['jour']);
    $mois = intval($_POST['mois']);
    $annee = intval($_POST['annee']);
    $heure = intval($_POST['heure']);
    $minutes = intval($_POST['minutes']);
    $secondes = intval($_POST['secondes']);
    $longitude = floatval($_POST['longitude']);
    $latitude = floatval($_POST['latitude']);
    $sog = floatval($_POST['sog']);
    $cog = floatval($_POST['cog']);
    $heading = intval($_POST['heading']);
    $status = intval($_POST['status']);
    $longueur = intval($_POST['longueur']);
    $largeur = intval($_POST['largeur']);
    $tirant = intval($_POST['tirant']);

    $result = dbAjoutPoint($db, $mmsi, $nom, $jour, $mois, $annee, $heure, $minutes, $secondes, $longitude, $latitude, $sog, $cog, $heading, $status, $longueur, $largeur, $tirant);

    if ($result === false) {
        // dbAjoutPoint doit retourner false en cas d’erreur
        http_response_code(500);
        echo json_encode(["success" => false, "error" => "Erreur lors de l'insertion en base de données"]);
        exit;
    }

    // Succès
    echo json_encode(["success" => true]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["success" => false, "error" => $e->getMessage()]);
    exit;
}

?>