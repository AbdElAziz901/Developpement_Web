<?php
// Verification que la requête est bien en POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}

// Récupération des données JSON envoyées
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['latitude'], $data['longitude'], $data['SOG'], $data['heading'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Paramètres manquants']);
    exit;
}

// Sécuriser les entrées
$latitude = escapeshellarg($data['latitude']);
$longitude = escapeshellarg($data['longitude']);
$SOG = escapeshellarg($data['SOG']);
$heading = escapeshellarg($data['heading']);

// Commande
$command = "python3 ../python/trajectoire.py --lat $latitude --lon $longitude --sog $SOG --heading $heading";

// Exécution le script Python et capturer la sortie
$output = [];
$return_var = 0;
exec($command, $output, $return_var);

if ($return_var !== 0) {
    echo json_encode(['error' => 'Erreur lors de l\'exécution du script Python', 'details' => $output]);
    exit;
}

// Retourner la sortie JSON du script Python
header('Content-Type: application/json; charset=utf-8');
echo implode("", $output);
?>
