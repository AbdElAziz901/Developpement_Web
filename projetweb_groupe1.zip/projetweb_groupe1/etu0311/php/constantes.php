<?php 
    define('DB_SERVER', 'localhost');
    define('DB_NAME', 'etu0311');
    define('DB_USER', 'etu0311'); 
    define('DB_PASSWORD', 'lnnkbaql'); 
?>