<?php
header('Content-Type: application/json');

// Lecture de l'entrée JSON envoyée en POST
$input = json_decode(file_get_contents('php://input'), true);

// Log pour débogage
error_log(print_r($input, true));

if (!$input) {
    http_response_code(400);
    echo json_encode(['error' => 'Entrée JSON invalide']);
    exit;
}

// Construction sécurisée des arguments
$sog = escapeshellarg($input['SOG']);
$cog = escapeshellarg($input['COG'] ?? 0);
$latitude = escapeshellarg($input['latitude'] ?? 0);
$longitude = escapeshellarg($input['longitude'] ?? 0);
$heading = escapeshellarg($input['heading'] ?? 0);
$length = escapeshellarg($input['length'] ?? 0);
$width = escapeshellarg($input['width'] ?? 0);
$draft = escapeshellarg($input['draft'] ?? 0);
$status = escapeshellarg($input['state_id'] ?? 0);
$time = escapeshellarg($input['created_at'] ?? '');

// Construction de la commande à exécuter
$command = "python3 ../python/type.py"
    . " --sog $sog"
    . " --cog $cog"
    . " --latitude $latitude"
    . " --longitude $longitude"
    . " --heading $heading"
    . " --length $length"
    . " --width $width"
    . " --draft $draft"
    . " --status $status"
    . " --time $time";

// Log de la commande exécutée
error_log("Commande : $command");

// Exécution du script Python
$output = [];
$return_var = 0;
exec($command, $output, $return_var);

// Log des résultats
error_log("Retour exec : $return_var");
error_log("Sortie exec : " . print_r($output, true));

// Vérification de l’exécution
if ($return_var !== 0 || empty($output)) {
    echo json_encode(['error' => 'Erreur lors de l\'exécution du script Python', 'details' => $output]);
    exit;
}

// Nettoyage de la sortie pour éviter toute erreur de format JSON
$json_str = implode("", $output);
$json_data = json_decode($json_str, true);

// Vérification que la sortie est bien un JSON
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(['error' => 'Sortie JSON invalide du script Python', 'raw' => $json_str]);
    exit;
}

// Réponse propre au frontend
echo json_encode($json_data);
