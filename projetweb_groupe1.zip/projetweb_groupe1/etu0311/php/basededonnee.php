<?php
    require_once("constantes.php");

    function dbConnect(){
        try {
            $connexion = 'mysql:host='.DB_SERVER.';dbname='.DB_NAME.';charset=utf8';
            $db = new PDO($connexion, DB_USER, DB_PASSWORD);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $db;
            } 
        catch (PDOException $exception) {
            error_log('Connection error: '.$exception->getMessage());
            header('HTTP/1.1 503 Service Unavailable');
            return false;
            }
    }

    function dbGetStates($db) {
        try {
            // D'abord vérifier les tables existantes
            $tables = $db->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            error_log("Tables disponibles: ".print_r($tables, true));
            //echo("J'ai une base de données");
            
            // Ensuite vérifier la structure de la table state si elle existe
            if(in_array('state', $tables)) {
                $structure = $db->query("DESCRIBE state")->fetchAll(PDO::FETCH_ASSOC);
                error_log("Structure de state: ".print_r($structure, true));
            }
            
            $stmt = $db->query('SELECT id, name FROM state');
            $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
            error_log("Résultats: ".print_r($result, true));
            return $result;
        } catch (PDOException $e) {
            error_log('Erreur complète: '.$e->getMessage());
            //echo("J'ai PAS de base de données");
            return false;
        }
    }

    function dbAjoutPoint($db, $mmsi, $nom, $jour, $mois, $annee, $heure, $minutes, $secondes, $longitude, $latitude, $sog, $cog, $heading, $status, $longueur, $largeur, $tirant){ 

        $datetime = sprintf('%04d-%02d-%02d %02d:%02d:%02d', $annee, $mois, $jour, $heure, $minutes, $secondes);

        try {
            // Vérifier si le bateau existe déjà
            $stmt = $db->prepare("SELECT COUNT(*) FROM boat WHERE MMSI = :mmsi");
            $stmt->execute([':mmsi' => $mmsi]);
            $exists = $stmt->fetchColumn();

            if ($exists) {
                // Mettre à jour le bateau existant
                $request = "UPDATE boat SET nom = :nom, longueur = :longueur, largeur = :largeur, tirant = :tirant, id_state = :statuts WHERE MMSI = :mmsi";
                $statement = $db->prepare($request);
                $statement->execute([
                    ':nom' => $nom,
                    ':longueur' => $longueur,
                    ':largeur' => $largeur,
                    ':tirant' => $tirant,
                    ':statuts' => $status,
                    ':mmsi' => $mmsi
                ]);
            } else {
                // Insérer un nouveau bateau
                $request = "INSERT INTO boat (MMSI, nom, longueur, largeur, tirant, id_state) VALUES (:mmsi, :nom, :longueur, :largeur, :tirant, :statuts)";
                $statement = $db->prepare($request);
                $statement->execute([
                    ':mmsi' => $mmsi,
                    ':nom' => $nom,
                    ':longueur' => $longueur,
                    ':largeur' => $largeur,
                    ':tirant' => $tirant,
                    ':statuts' => $status
                ]);
            }

            // Insérer le point de données (data_point)
            $request = "INSERT INTO data_point (latitude, longitude, SOG, COG, heading, created_at, MMSI) VALUES (:latitude, :longitude, :sog, :cog, :heading, :horodateur, :mmsi)";
            $statement = $db->prepare($request);
            $statement->execute([
                ':latitude' => $latitude,
                ':longitude' => $longitude,
                ':sog' => $sog,
                ':cog' => $cog,
                ':heading' => $heading,
                ':horodateur' => $datetime,
                ':mmsi' => $mmsi
            ]);

            return true;

        } catch (PDOException $exception) {
            error_log('Erreur SQL: '.$exception->getMessage());
            return false;
        }
    }

?>