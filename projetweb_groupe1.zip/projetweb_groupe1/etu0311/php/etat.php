<?php
    header('Content-Type: application/json; charset=utf-8');
    header("Access-Control-Allow-Origin: *");

    require_once("basededonnee.php");

    $db = dbConnect();
    if($db === false) {
        http_response_code(500);
        die(json_encode(["error" => "Database connection failed"]));
    }

    $req = $_GET['request'] ?? '';

    if($req === 'states') {
        $tab_states = dbGetStates($db);
        if($tab_states === false) {
            http_response_code(500);
            die(json_encode(["error" => "Failed to fetch states"]));
        }
        echo json_encode($tab_states, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    } else {
        http_response_code(400);
        echo json_encode(["error" => "Invalid request"]);
    }



