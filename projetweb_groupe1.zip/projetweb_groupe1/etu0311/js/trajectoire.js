"use strict";

window.addEventListener("DOMContentLoaded", () => {
  const data = JSON.parse(localStorage.getItem("traj_prediction"));
  console.log(data);
  if (!data) {
    alert("Aucune donnée de trajectoire trouvée.");
    return;
  }

  // Affichage sur la carte Plotly
  const traceOrigine = {
    type: "scattermapbox",
    mode: "markers",
    lat: [data.latitude_origine],
    lon: [data.longitude_origine],
    marker: { size: 10, color: "blue" },
    name: "Point d'origine"
  };

  const tracePred = {
    type: "scattermapbox",
    mode: "markers",
    lat: [data.latitude_predite],
    lon: [data.longitude_predite],
    marker: { size: 10, color: "red" },
    name: "Prédiction"
  };

  const traceLigne = {
    type: "scattermapbox",
    mode: "lines",
    lat: [data.latitude_origine, data.latitude_predite],
    lon: [data.longitude_origine, data.longitude_predite],
    line: { color: "green", width: 2 },
    name: "Trajectoire"
  };

  const layout = {
    mapbox: {
      style: "open-street-map",
      center: {
        lat: (data.latitude_origine + data.latitude_predite) / 2,
        lon: (data.longitude_origine + data.longitude_predite) / 2
      },
      zoom: 6
    },
    margin: { t: 0, b: 0 }
  };

  Plotly.newPlot("carte_traj", [traceOrigine, tracePred, traceLigne], layout, {responsive: true});
});
