'use strict';

function displayStates(tab){
    let menu = document.getElementById('etat-list');

    let txt;
    let val;

    menu.innerHTML=''; // effacer le contenu actuel du menu

    menu.innerHTML="<option value='0'>En route avec moteur</option>"; 

    //Sans utiliser d'élément i , ne marche que si on veut prendre les éléments 1 par 1 (pas de 1 sur 2)

    for(let statut of tab){
        //statut contient un element du tableau tab
        txt=statut['name'];
        val=statut['id'];
        if(val!=1){
            menu.options.add(new Option(txt,val));
        }
    }
}

function displayErrors(code){
    let messages = {
        400: 'Requête incorrecte',
        401: 'Authentifiez-vous',
        403: 'Accès refusé',
        404: 'Page non trouvée',
        500: 'Erreur interne du serveur',
        503: 'Service indisponible'
        };
    
    let baliseh2 = document.createElement('h2'); // createElement('h2') crée un élément comme celui-ci : <h2></h2>
    baliseh2.innerHTML= messages[code]; // écrire dans la balise h2 le texte correspondant au code
    
    let derniereligne = document.getElementById('taille-area'); // récupérer la zone de formulaire de chat-area

    derniereligne.appendChild(baliseh2); // ajouter la balise h2 après la zone de formulaire de chat-area
    setTimeout(() => {
        // supprimer la balise h2 du docuemnt (après chat-area)
        derniereligne.removeChild(baliseh2);
        }, 5000); // s'éxecutera au bout de 5 secondes (5000 milisecondes)
}

async function getStates() {
    const url = 'php/etat.php?request=states';
    
    try {
        console.log("Envoi de la requête à:", url);
        const response = await fetch(url);
        
        if (!response.ok) {
            const error = await response.json().catch(() => null);
            throw new Error(error?.details || `Erreur HTTP: ${response.status}`);
        }
        
        const data = await response.json();
        console.log("Réponse reçue:", data);
        displayStates(data);
        
    } catch (error) {
        console.error("Échec de la requête:", error.message);
        displayErrors(500);
    }
}
getStates();





document.getElementById('formulaire').addEventListener('submit', sendpoint);
    
async function sendpoint(event){
    event.preventDefault();

    let form = document.getElementById("formulaire");

    let mmsi = document.getElementById('mmsi-number').value;
    let nom = document.getElementById('nom-du-bateau').value;
    let jour = document.getElementById('jour').value;
    let mois = document.getElementById('mois').value;
    let annee = document.getElementById('annee').value;
    let heure = document.getElementById('heure').value;
    let minutes = document.getElementById('minutes').value;
    let secondes = document.getElementById('secondes').value;
    let longitude = document.getElementById('lon').value;
    let latitude = document.getElementById('lat').value;
    let sog = document.getElementById('vit').value;
    let cog = document.getElementById('direction').value;
    let heading = document.getElementById('heading').value;
    let status = document.getElementById('etat-list').value;
    let longueur = document.getElementById('long').value;
    let largeur = document.getElementById('larg').value;
    let tirant = document.getElementById('t-eau').value;

    form.reset();
    
    let data = "mmsi="+mmsi+"&nom="+nom+"&jour="+jour+"&mois="+mois+"&annee="+annee+"&heure="+heure+"&minutes="+minutes+"&secondes="+secondes+"&longitude="+longitude+"&latitude="+latitude+"&sog="+sog+"&cog="+cog+"&heading="+heading+"&status="+status+"&longueur="+longueur+"&largeur="+largeur+"&tirant="+tirant ;
    try {
        const response = await fetch('../php/formulaire.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
            },
            body: data
        });
        console.log("Données envoyées", data);

        if (response.ok) {
            alert("Point ajouté avec succès !");
        } else {
            const error = await response.json();
            alert("Erreur : " + error.error);
        }

    } catch (error) {
        console.error('Erreur:', error);
        alert("Erreur réseau : " + error.message);
    }
}

