const data = JSON.parse(localStorage.getItem("selectedBoat") || "{}");

console.log("Données récupérées :", data);

if (
  data.width == null || data.draft == null ||
  data.length == null || data.heading == null
) {
  document.getElementById("result").textContent = "Erreur : données manquantes.";
} else {
  document.getElementById("loading").style.display = "block";
  document.getElementById("result").textContent = "";

  console.log("Données envoyées au serveur :", JSON.stringify(data));
  
  fetch("php/predict_type.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  })
    .then(res => res.json())
    .then(response => {
      document.getElementById("loading").style.display = "none";
      if (response.error) {
        document.getElementById("result").textContent = "Erreur : " + response.error;
      } else {
        document.getElementById("result").textContent = "Type prédit : " + response.prediction;
      }
    })
    .catch(err => {
      document.getElementById("loading").style.display = "none";
      document.getElementById("result").textContent = "Erreur réseau : " + err;
    });
}
