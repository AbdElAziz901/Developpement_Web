"use strict";

document.addEventListener("DOMContentLoaded", async () => {
  const boats = JSON.parse(localStorage.getItem("boats_data"));
  console.log("Données bateaux récupérées :", boats);

  if (!boats || boats.length === 0) {
    alert("Aucune donnée bateau trouvée !");
    return;
  }

  // Prédire les clusters pour chaque bateau
  const predictions = await Promise.all(
    boats.map(async (boat) => {
      try {
        const response = await fetch("php/cluster.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(boat)
        });

        const result = await response.json();

        console.log(`Cluster prédit pour ${boat.nom} :`, result.cluster);
        return { ...boat, cluster: Number.isInteger(result.cluster) ? result.cluster : 0 };

      } catch (error) {
        console.error(`Erreur lors de la prédiction pour ${boat.nom}`, error);
        return { ...boat, cluster: 0 }; // Valeur par défaut en cas d'erreur
      }
    })
  );

  afficherCarteClusters(predictions);
});

function afficherCarteClusters(data) {
  console.log("Données avec clusters :", data);

  const traces = data.map(p => {
    const cluster = Number.isInteger(p.cluster) ? p.cluster : 0;

    return {
      type: "scattermapbox",
      mode: "markers",
      lat: [parseFloat(p.latitude)],
      lon: [parseFloat(p.longitude)],
      text: `
        <b>${p.nom ?? "N/A"}</b><br>
        Cluster : ${cluster}<br>
        SOG : ${p.SOG ?? "N/A"} kn<br>
        COG : ${p.COG ?? "N/A"}°<br>
        Date : ${p.created_at ?? "N/A"}
      `,
      name: `Cluster ${cluster}`,
      marker: {
        size: 10,
        color: `hsl(${cluster * 60}, 100%, 50%)`
      }
    };
  });

  const layout = {
    mapbox: {
      style: "open-street-map",
      center: {
        lat: parseFloat(data[0].latitude),
        lon: parseFloat(data[0].longitude)
      },
      zoom: 4
    },
    margin: { t: 0, b: 0 },
    hovermode: "closest"
  };

  Plotly.newPlot("map", traces, layout, { responsive: true });
}
